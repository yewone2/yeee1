package com.example.breadmap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BreadMapApplication {

	public static void main(String[] args) {
		SpringApplication.run(BreadMapApplication.class, args);
	}

}
